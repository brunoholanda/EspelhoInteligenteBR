/* Magic Mirror Deprecated Config Options List
 *
 * By Michael Teeuw http://michaelteeuw.nl
 * MIT Licensed.
 *
 * Olex S. original idea this deprecated option
 */

var deprecated = {
	configs: ["kioskmode"],
};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") {module.exports = deprecated;}
